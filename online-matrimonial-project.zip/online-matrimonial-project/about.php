<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Find Your Perfect Partner - Matrimony | About :: Matrimony
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
</head>
<body>
<!-- ============================  Navigation Start =========================== -->
 <?php include_once("includes/navigation.php");?>
<!-- ============================  Navigation End ============================ -->
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.php"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page">About</li>
     </ul>
   </div>
   <div class="about">
   	  <div class="col-md-6 about_left">
   	  	<img src="images/a3.jpg" class="img-responsive" alt=""/>
   	  </div>
   	  <div class="col-md-6 about_right">
   	  	<h1>About us</h1>
   	  	<p>A passionate Company of thinkers, innovators, creatives, strategists, technominds dedicated to creating the most impactful IT solutions . TECHNO MIND offer a core set of Information Technology services to help improve the online visibility and impact of your business.We are a connection, a strategy, a measurable idea, a result, a plan. We are a digital modern shop built on a foundation of Web development, software development, front end design, database creation, and programming that’s grown into all that and a full force tech web development outfit. We are people who understand and proactively adapt to the changing face of the internet while mastering the strategies and technologies. Our goal to deliver the best and quality services to our clients is one of the top growing IT solution and service providers.
        We are a team of selected creatives brought together on a mission to contrive magnificent web development and designs putting in right marketing strategies and let our designs speak out to conquer the market. We started with a vision to provide self-evident quality in IT solutions. “Quality and delivery on time is the motto” of Company. We are here to deliver a premium solutions for a wide range of business. we have an experienced and dedicated team of IT professionals. Our Company is your best choice for a wide range of IT services. We are working closely to understand your business requirements and utilize the appropriate technology to get you the best.</p>
   	  	
   	  <div class="clearfix"> </div>
   </div>
  </div>
</div>
<div class="about_middle">
	<div class="container">
	  <h2>Happy Clients</h2>
	  <div class="about_middle-grid1">
		<div class="col-sm-6 testi_grid list-item-0">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="https://img.shaadi.com/success-story/nSH03391386-QSH41119319-big.jpg" class="img-responsive" alt=""/>
				</figure>
				<div><a href="about.php">I found my match on matrimony website.....Thanks.,.</a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
		    <small class="testi-meta"><span class="user">Nisarg & Priyansh</span></small>
		</div>
		<div class="col-sm-6 testi_grid list-item-1">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="https://img.shaadi.com/success-story/gSH16126261-tSH15869930-big.jpg" class="img-responsive" alt=""/>
				</figure>
				<div><a href="about.php">I found my soulmate Thanks to matrimony website for this wonderful platform.,.</a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
			<small class="testi-meta1"><span class="user">Dilnoor & Roop</span></small>
		</div>
		<div class="clearfix"> </div>
	  </div>
	  <div class="about_middle-grid2">
		<div class="col-sm-6 testi_grid list-item-0">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="https://img.shaadi.com/success-story/TSH79287394-4SH27519520-big.jpg" class="img-responsive" alt=""/>
				</figure>
				<div><a href="about.php">We found each other on matrimony website thanks..</a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
		    <small class="testi-meta"><span class="user">Ajit & Pooja</span></small>
		</div>
		<div class="col-sm-6 testi_grid list-item-1">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="https://img.shaadi.com/success-story/FSH30388691-kSH26387757-big.jpg" class="img-responsive" alt=""/>
				</figure>
				<div><a href="about.php">It was a beautiful experience thanks matrimony website I found my partner..</a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
			<small class="testi-meta1"><span class="user">Nitin & Mitali</span></small>
		</div>
		<div class="clearfix"> </div>
	  </div>
	</div>
</div>

	   <div class="clearfix"> </div>
	</div>
</div>


<?php include_once("footer.php");?>

	