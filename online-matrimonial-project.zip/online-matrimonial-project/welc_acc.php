<?php 
if($_SESSION["username"])
?>

Welcome <?php echo "".$_SESSION["username"];?>