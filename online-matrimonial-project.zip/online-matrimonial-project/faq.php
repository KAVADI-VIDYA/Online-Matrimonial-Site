<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Find Your Perfect Partner - Matrimony | Faq :: Matrimony
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
</head>
<body>
<!-- ============================  Navigation Start =========================== -->
<?php include_once("includes/navigation.php");?>
<!-- ============================  Navigation End ============================ -->
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.php"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page">FAQ</li>
     </ul>
   </div>
   <dl class="faq-list">
	<dt class="faq-list_h">
	<h4 class="marker">Q1</h4>
	<h4>Can I register a matrimonial profile on behalf of a relative??</h4>
	</dt>
	<dd>
	<h4 class="marker1">A.</h4>
	<p class="m_4">Yes, You can register on behalf of your relative.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q2</h4>
	<h4>What is partner preference?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">Partner Preference essentially includes details that you would desire in your preferred partner. This gives us better understanding of your ideal partner and we suggest better matches based on your preference. Also, other members understand that what kind of partner you are looking for.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q3</h4>
	<h4>What is Search By Profile ID?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">This is auto- generated unique Id. This unique Id is for every individual who has registered on this website. It is important and helpful because a user can see your profile details through the profile ID and Existing profiles</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q4</h4>
	<h4>Can I choose my own ID??</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">No, It’s generated automatically.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q5</h4>
	<h4>Why should I attach my photograph to my profile?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">A picture is worth a thousand words and makes your profile truly come alive!! Our statistics have clearly revealed that adding photographs to your matrimonial profile not only increase the number of times your profile is viewed but also multiplies the level of responses to your profile. And in addition, it enables you to get featured in Photo Searches.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q6</h4>
	<h4>How can I Edit my profile?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">You can easily edit your profile following these steps:

     Login with your email-id and Password, then click on “Update profile" Link. Then select from various sections of profile information you wish to update</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q7</h4>
	<h4>How will Candidate contact me?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4 m_5">If any person interested in your profile they will contact you through our reference. Some people contact you after seen your profile on website</p>
	</dd>
    <br>
	<dt class="faq-list_h">
	<h4 class="marker">Q8</h4>
	<h4>How can I search for my partner? What are the search options available?</h4>
	</dt>
	
	<dd>
    <h4 class="marker">A.</h4>
	<p class="m_4 m_5">The search has been designed in a user-friendly way so that it is always effective and yields the results that you are looking for. You can simply login and click on "search" to opt for type and go ahead finding your match.</p>
	</dd>
	<br>

	<dt class="faq-list_h">
	<h4 class="marker">Q9</h4>
	<h4>What is regular search?</h4>
	</dt>

	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4 m_5">One can search his/her partner accordingly by entering the required details.</p>
	</dd>
     <br>
	<dt class="faq-list_h">
	<h4 class="marker">Q10</h4>
	<h4>&nbsp;&nbsp;What is search from existing profile?</h4>
	</dt>

	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4 m_5"> One can search his/her partner from all registered  candidates on this website.</p>
	</dd>
	<br>

    <dt class="faq-list_h">
	<h4 class="marker">Q11</h4>
	<h4>&nbsp;&nbsp;How I can view Candidate Photo?</h4>
	</dt>

	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4 m_5">By using search option you can view Profile of candidate & Photo.</p>
	</dd>
     



   </dl>
  </div>
</div>


<?php include_once("footer.php");?>

